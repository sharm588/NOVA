Native libraries for LTI-CIVIL has been taken from [this LTI-CIVIL patch](http://sourceforge.net/p/lti-civil/patches/4/)
submitted by [George Rhoten](http://sourceforge.net/u/blackdiamond/profile/) at 2012-04-23.

All can be found in the following ZIP files:

* [lti-civil-bin32.zip](http://sourceforge.net/p/lti-civil/patches/_discuss/thread/cb267e8d/6b31/attachment/lti-civil-bin32.zip)
* [lti-civil-bin64-linux.zip](http://sourceforge.net/p/lti-civil/patches/_discuss/thread/cb267e8d/6c3d/attachment/lti-civil-bin64-linux.zip)
* [lti-civil-bin64-windows.zip](http://sourceforge.net/p/lti-civil/patches/_discuss/thread/cb267e8d/9579/attachment/lti-civil-bin64-windows.zip)



