# WebcamPanel in SWT Application Example

This example show one of the methods of how ```WebcamPanel``` can be used 
in SWT-based appliaction.


